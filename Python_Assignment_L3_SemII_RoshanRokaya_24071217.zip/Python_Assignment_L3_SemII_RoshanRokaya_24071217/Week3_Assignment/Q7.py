import csv

# Define the Employee class
class Employee:
    def __init__(self, empid, name, address, contact_number, spouse_name, number_of_child, salary):
        self.empid = empid
        self.name = name
        self.address = address
        self.contact_number = contact_number
        self.spouse_name = spouse_name
        self.number_of_child = number_of_child
        self.salary = salary

    # Return employee data as a list (for CSV writing)
    def to_list(self):
        return [
            self.empid, self.name, self.address,
            self.contact_number, self.spouse_name,
            self.number_of_child, self.salary
        ]

# Function to add multiple employees and write to file
def add_employees():
    try:
        num = int(input("Enter the number of employees to add: "))
        employees = []

        for i in range(num):
            print(f"\nEnter details for Employee {i+1}:")
            empid = input("Employee ID: ")
            name = input("Name: ")
            address = input("Address: ")
            contact_number = input("Contact Number: ")
            spouse_name = input("Spouse Name: ")
            number_of_child = input("Number of Children: ")
            salary = input("Salary: ")

            emp = Employee(empid, name, address, contact_number, spouse_name, number_of_child, salary)
            employees.append(emp)

        # Write to CSV file
        with open("employees.csv", "a", newline='') as file:
            writer = csv.writer(file)
            # Write header if file is empty
            file.seek(0)
            if file.tell() == 0:
                writer.writerow([
                    "EmpID", "Name", "Address",
                    "Contact Number", "Spouse Name",
                    "Number of Children", "Salary"
                ])
            for emp in employees:
                writer.writerow(emp.to_list())

        print("\nEmployee(s) added successfully.")

    except ValueError:
        print("Please enter valid numbers where required.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Function to display employees from the file
def display_employees():
    try:
        with open("employees.csv", "r") as file:
            reader = csv.reader(file)
            rows = list(reader)

            if len(rows) <= 1:
                print("No employee records found.")
                return

            print("\n--- Employee Records ---")
            for row in rows:
                print(', '.join(row))

    except FileNotFoundError:
        print("Employee file not found. Please add employees first.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Main program menu
def main():
    while True:
        print("\n--- Employee Management System ---")
        print("1. Add Employees")
        print("2. View Employees")
        print("3. Exit")

        choice = input("Enter your choice (1-3): ")

        if choice == '1':
            add_employees()
        elif choice == '2':
            display_employees()
        elif choice == '3':
            print("Exiting the program!")
            break
        else:
            print("Invalid choice! Please select from 1 to 3.")

# Run the program
main()