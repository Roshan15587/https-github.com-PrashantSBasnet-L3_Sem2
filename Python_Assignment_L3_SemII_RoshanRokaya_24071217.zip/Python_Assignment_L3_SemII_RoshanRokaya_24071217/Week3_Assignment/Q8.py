import csv
import os

# Define the Book class
class Book:
    def __init__(self, book_id, title, author, available=True):
        self.book_id = book_id
        self.title = title
        self.author = author
        self.available = available

    def to_list(self):
        return [self.book_id, self.title, self.author, "Yes" if self.available else "No"]

# Library Management Class
class Library:
    def __init__(self, filename="books.csv"):
        self.filename = filename
        self.books = self.load_books()

    # Load books from file
    def load_books(self):
        books = []
        try:
            if os.path.exists(self.filename):
                with open(self.filename, 'r') as file:
                    reader = csv.reader(file)
                    next(reader)  # Skip header
                    for row in reader:
                        if len(row) == 4:
                            book_id, title, author, available = row
                            book = Book(book_id, title, author, available == "Yes")
                            books.append(book)
        except Exception as e:
            print(f"Error reading file: {e}")
        return books

    # Save books to file
    def save_books(self):
        try:
            with open(self.filename, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Book ID", "Title", "Author", "Available"])
                for book in self.books:
                    writer.writerow(book.to_list())
        except Exception as e:
            print(f"Error writing to file: {e}")

    # Search for a book by title or ID
    def search_book(self):
        search = input("Enter Book Title or ID to search: ").lower()
        found = False
        for book in self.books:
            if search in book.book_id.lower() or search in book.title.lower():
                status = "Available" if book.available else "Issued"
                print(f"\nBook ID: {book.book_id}, Title: {book.title}, Author: {book.author}, Status: {status}")
                found = True
        if not found:
            print("No matching book found.")

    # Issue a book
    def issue_book(self):
        book_id = input("Enter Book ID to issue: ").strip()
        for book in self.books:
            if book.book_id == book_id:
                if book.available:
                    book.available = False
                    self.save_books()
                    print(f"Book '{book.title}' has been issued.")
                else:
                    print("Sorry, this book is already issued.")
                return
        print("Book not found.")

    # Return a book
    def return_book(self):
        book_id = input("Enter Book ID to return: ").strip()
        for book in self.books:
            if book.book_id == book_id:
                if not book.available:
                    book.available = True
                    self.save_books()
                    print(f"Book '{book.title}' has been returned.")
                else:
                    print("This book was not issued.")
                return
        print("Book not found.")

    # Add a new book (optional feature)
    def add_book(self):
        book_id = input("Enter Book ID: ")
        title = input("Enter Book Title: ")
        author = input("Enter Author Name: ")
        book = Book(book_id, title, author)
        self.books.append(book)
        self.save_books()
        print("Book added successfully.")

# Main Program
def main():
    library = Library()

    while True:
        print("\n--- Library Book Management ---")
        print("1. Search Book")
        print("2. Issue Book")
        print("3. Return Book")
        print("4. Add Book")
        print("5. Exit")

        choice = input("Enter your choice (1-5): ")

        if choice == '1':
            library.search_book()
        elif choice == '2':
            library.issue_book()
        elif choice == '3':
            library.return_book()
        elif choice == '4':
            library.add_book()
        elif choice == '5':
            print("Exiting the program")
            break
        else:
            print("Invalid choice! Please enter a number from 1 to 5.")

# Run the main program
main()
