import csv
# Function to read and display CSV file contents in tabular form
def display_csv_table(filename):
    try:
        # Open the CSV file in read mode
        with open(filename, 'r', newline='') as file:
            reader = csv.reader(file)

            rows = list(reader)  # Read all rows into a list

            if not rows:
                print("The file is empty.")
                return

            # Get the maximum width of each column for formatting
            col_widths = [max(len(str(cell)) for cell in col) for col in zip(*rows)]

            # Function to format a single row
            def format_row(row):
                return " | ".join(cell.ljust(width) for cell, width in zip(row, col_widths))

            # Print header row with separator
            print(format_row(rows[0]))
            print("-" * (sum(col_widths) + 3 * (len(col_widths) - 1)))

            # Print data rows
            for row in rows[1:]:
                print(format_row(row))

    except FileNotFoundError:
        print(f"Error: File '{filename}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
display_csv_table("students.csv")  # Make sure this file exists
