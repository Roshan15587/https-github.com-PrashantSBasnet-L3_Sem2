# Define the Student class
class Student:
    def __init__(self):
        # Initialize all attributes with default values
        self.id = ""
        self.name = ""
        self.address = ""
        self.admission_year = ""
        self.level = ""
        self.section = ""

    # Method to take input for student attributes
    def input_details(self):
        self.id = input("Enter Student ID: ")
        self.name = input("Enter Student Name: ")
        self.address = input("Enter Address: ")
        self.admission_year = input("Enter Admission Year: ")
        self.level = input("Enter Level (e.g., Grade 10): ")
        self.section = input("Enter Section: ")

    # Method to display student details
    def display_details(self):
        print("\n--- Student Details ---")
        print(f"ID: {self.id}")
        print(f"Name: {self.name}")
        print(f"Address: {self.address}")
        print(f"Admission Year: {self.admission_year}")
        print(f"Level: {self.level}")
        print(f"Section: {self.section}")

# Create an object of the Student class
student1 = Student()

# Take input and display output
student1.input_details()
student1.display_details()
