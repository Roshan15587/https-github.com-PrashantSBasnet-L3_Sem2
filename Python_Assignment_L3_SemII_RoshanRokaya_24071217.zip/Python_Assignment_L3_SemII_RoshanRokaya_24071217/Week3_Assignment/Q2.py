#question number-2; weeek-3
sender_file = "Roshan.txt" 
reciever_file = "Rokaya.txt" 

try: 

    with open(sender_file, 'r') as sender:
        with open(reciever_file, 'w') as reciever:
            overall = sender.read()
            reciever.write(overall)
            print("Content of the file has been successfully copied.")

except FileNotFoundError:  
    print(f"One of the files was not found.")