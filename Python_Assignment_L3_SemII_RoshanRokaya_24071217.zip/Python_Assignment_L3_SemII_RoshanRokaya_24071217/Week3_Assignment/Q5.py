# Function to count the occurrence of each word in a file
def count_word_occurrences(filename):
    try:
        # Open the file in read mode
        with open(filename, 'r') as file:
            text = file.read()  # Read the entire file content

        # Remove punctuation and convert text to lowercase
        for char in "-.,\n!?;:":
            text = text.replace(char, " ")
        text = text.lower()

        # Split the text into words
        words = text.split()

        # Dictionary to store word counts
        word_count = {}
        # Count each word
        for word in words:
            if word in word_count:
                word_count[word] += 1  # Increment count if word exists
            else:
                word_count[word] = 1   # Add word to dictionary

        # Display the results
        print("Word Occurrence Count:\n")
        for word, count in word_count.items():
            print(f"{word}: {count}")

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Example usage
count_word_occurrences("Roshan.txt")  # Replace with your filename
