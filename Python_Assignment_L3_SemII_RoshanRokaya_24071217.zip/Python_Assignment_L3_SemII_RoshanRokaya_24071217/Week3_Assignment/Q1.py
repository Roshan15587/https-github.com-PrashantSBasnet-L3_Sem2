#question number-1;
file_name = "Roshan.txt"  

try: 
    with open(file_name, 'r') as file:  
        num_line = 0 
        num_words = 0
        num_characters = 0 
        for line in file:  
            num_line += 1  
            num_words += len(line.split())  
            num_characters += len(line) 
        print(f"The number of lines: {num_line}") 
        print(f"The number of words: {num_words}") 
        print(f"The number of characters: {num_characters}") 

except FileNotFoundError:  
    print(f"The file '{file_name}' was not found.")

