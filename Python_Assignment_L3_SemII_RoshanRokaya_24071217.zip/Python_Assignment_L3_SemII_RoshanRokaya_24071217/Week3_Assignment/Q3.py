# Program to find and replace a specific word in a file

# Function to replace a word in a file
def find_and_replace(filename, old_word, new_word):
    try:
        # Open the file in read mode
        with open(filename, 'r') as file:
            content = file.read()  # Read the entire content of the file

        # Replace all of the old word with the new word
        updated_content = content.replace(old_word, new_word)

        # Open the file in write mode to overwrite it with updated content
        with open(filename, 'w') as file:
            file.write(updated_content)

        print(f"All occurrences of '{old_word}' have been replaced with '{new_word}'.")
    
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Replace "oldword" with "newword" in "example.txt"
find_and_replace('example.txt', 'oldword', 'newword')
