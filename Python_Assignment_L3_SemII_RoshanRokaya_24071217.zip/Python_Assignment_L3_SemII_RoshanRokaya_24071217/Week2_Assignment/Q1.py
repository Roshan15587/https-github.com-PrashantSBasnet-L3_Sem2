def case(s):

    """This function counts the number of uppercase and lowercase letters in a string."""
    upper = sum(1 for c in s if c.isupper())
    lower = sum(1 for c in s if c.islower())
    return upper, lower

s = "Every Moment is a Fresh Beginning"
print(case(s))  