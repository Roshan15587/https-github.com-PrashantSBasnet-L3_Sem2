def prime(n):
    
    """This function checks whether a given number is prime or not."""
    if n < 2:
        return False
    return all(n % i != 0 for i in range(2, int(n**0.5) + 1))
print(prime(11))  
print(prime(10))