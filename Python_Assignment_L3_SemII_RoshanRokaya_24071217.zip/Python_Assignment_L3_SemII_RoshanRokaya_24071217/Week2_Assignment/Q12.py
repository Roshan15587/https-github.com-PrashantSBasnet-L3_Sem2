def word_intersection():
    """Prompts the user for two words and displays the common letters."""
    word1 = input("Enter the first word: ").lower()
    word2 = input("Enter the second word: ").lower()
    
    # Find common letters
    common_letters = set(word1) & set(word2)
    
    # Display the result
    if common_letters:
        print(f"Common letters: {', '.join(common_letters)}")
    else:
        print("No common letters.")

word_intersection()