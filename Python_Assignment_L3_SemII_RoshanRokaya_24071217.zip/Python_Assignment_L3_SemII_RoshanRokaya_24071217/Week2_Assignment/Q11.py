# Sets
set1 = {20, 40, 60}
set2 = {10, 20, 30, 40, 50, 60}

# (a) Union of the sets
union_set = set1 | set2
print(len(union_set))  # Length of the union set

# (b) Intersection of the sets
intersection_set = set1 & set2
print(intersection_set)  # Common values between set1 and set2

# (c) Symmetric difference between the sets
sym_diff_set = set1 ^ set2
print(sym_diff_set)  # Values in set1 or set2 but not in both

# (d) Add 40 to set1
set1.add(40)
print(set1)  # Set remains the same (no change)

# (e) Remove 20 from set2
set2.remove(20)
print(set2)  # Set after removal
