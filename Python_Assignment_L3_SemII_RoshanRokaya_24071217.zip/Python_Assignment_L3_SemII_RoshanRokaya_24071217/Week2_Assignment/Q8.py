def add_daily_temp(temps, day, temp):
    """Adds temperature for a day if not already recorded."""
    if day not in temps:
        temps[day] = temp
    return temps

weekly_temps = {}
print(add_daily_temp(weekly_temps, "Sunday", 23.2))  
print(add_daily_temp(weekly_temps, "Tuesday", 30)) 
print(add_daily_temp(weekly_temps, "Sunday", 35))