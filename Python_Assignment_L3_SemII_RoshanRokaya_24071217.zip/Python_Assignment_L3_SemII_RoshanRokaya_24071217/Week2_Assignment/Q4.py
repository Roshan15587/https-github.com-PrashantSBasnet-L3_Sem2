def sort_names(names):
    #Sorts a list of names alphabetically.
    return sorted(names)


name_list = ["Apple", "Ball", "Cat", "Dog"]
sorted_names = sort_names(name_list)
print(sorted_names)