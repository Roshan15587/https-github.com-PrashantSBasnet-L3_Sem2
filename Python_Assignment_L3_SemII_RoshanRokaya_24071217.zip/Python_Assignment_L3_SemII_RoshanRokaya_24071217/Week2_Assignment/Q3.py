def armstrong(n):
    
    """This function checks whether a given number is an Armstrong number or not."""
    digits = [int(d) for d in str(n)]
    return n == sum(d ** len(digits) for d in digits)
print(armstrong(153))  
print(armstrong(123))  