# Dictionaries
dic1 = {1: 10, 2: 20}
dic2 = {3: 30, 4: 40}
dic3 = {5: 50, 6: 60}

# (a) Concatenate dictionaries to create nums
nums = {**dic1, **dic2, **dic3}
print(nums)  

# (b) Add a new key/value pair (7, 70)
nums[7] = 70
print(nums)  

# (c) Update the value of the item with key 3 to 80
nums[3] = 80
print(nums)  

# (d) Remove the third item from the dictionary
# Since dictionaries don't have an inherent order, we can use list conversion and pop by index
del nums[list(nums.keys())[2]]
print(nums) 

# (e) Sum all the items in the dictionary (sum of values)
total_sum = sum(nums.values())
print(total_sum)  

# (f) Multiply all the items in the dictionary (product of values)
from functools import reduce
from operator import mul
total_product = reduce(mul, nums.values(), 1)
print(total_product)  

# (g) Retrieve the maximum and minimum values in nums
max_value = max(nums.values())
min_value = min(nums.values())
print(f"Max: {max_value}, Min: {min_value}")  