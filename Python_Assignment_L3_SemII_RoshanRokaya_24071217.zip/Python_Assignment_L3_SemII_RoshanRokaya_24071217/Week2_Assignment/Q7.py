# Input two lists of integers
list1 = list(map(int, input("Enter integers for the first list separated by spaces: ").split()))
list2 = list(map(int, input("Enter integers for the second list separated by spaces: ").split()))

# (a) Check if the lists have the same length
if len(list1) == len(list2):
    print("The lists are of the same length.")
else:
    print("The lists are not of the same length.")

# (b) Check if the elements in the lists sum to the same value
if sum(list1) == sum(list2):
    print("The elements in both lists sum to the same value.")
else:
    print("The elements in the lists do not sum to the same value.")

# (c) Check for common values between the two lists
common_values = set(list1) & set(list2)
if common_values:
    print(f"The lists have common values: {common_values}")
else:
    print("The lists do not have any common values.")