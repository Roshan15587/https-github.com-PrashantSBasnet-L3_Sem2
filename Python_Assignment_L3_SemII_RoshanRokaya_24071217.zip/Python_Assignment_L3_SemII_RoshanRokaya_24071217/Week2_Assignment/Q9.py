def get_daily_temps():
    """Prompts the user for temperatures and returns a dictionary of daily temperatures."""
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    temps = {}
    for day in days:
        temp = float(input(f"Enter the temperature for {day}: "))
        temps[day] = temp
    return temps

daily_temps = get_daily_temps()
print(daily_temps)