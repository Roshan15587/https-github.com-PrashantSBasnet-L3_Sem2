# Input names and split them into a list
names = input("Enter names separated by commas: ").split(',')

# Count occurrences of 'a'
count_a = sum(name.lower().count('a') for name in names)

# Output the result
print(f"The letter 'a' appears {count_a} times.")
