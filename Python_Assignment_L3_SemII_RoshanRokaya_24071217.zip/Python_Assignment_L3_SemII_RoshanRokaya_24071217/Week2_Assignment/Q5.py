def add(a, b):
    """Returns the sum of two decimal numbers."""
    return a + b

def subtract(a, b):
    """Returns the difference between two decimal numbers."""
    return a - b

def multiply(a, b):
    """Returns the product of two decimal numbers."""
    return a * b

def divide(a, b):
    """Returns the quotient of two decimal numbers."""
    if b == 0:
        return "Error: Division by zero"
    return a / b

def truncated_division(a, b):
    """Returns the truncated division result of two decimal numbers."""
    if b == 0:
        return "Error: Division by zero"
    return a // b

def modulus(a, b):
    """Returns the remainder of the division of two decimal numbers."""
    if b == 0:
        return "Error: Division by zero"
    return a % b

def exponentiate(a, b):
    """Returns the result of raising the first number to the power of the second number."""
    return a ** b


a = 14.5
b = 3.0

print("Addition:", add(a, b))
print("Subtraction:", subtract(a, b))
print("Multiplication:", multiply(a, b))
print("Division:", divide(a, b))
print("Truncated Division:", truncated_division(a, b))
print("Modulus:", modulus(a, b))
print("Exponentiation:", exponentiate(a, b))
