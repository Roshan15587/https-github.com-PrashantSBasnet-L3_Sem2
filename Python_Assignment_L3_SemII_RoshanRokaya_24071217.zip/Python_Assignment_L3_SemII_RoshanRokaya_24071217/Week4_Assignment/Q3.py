import numpy as np

# Create 10 values between 0 and 1, excluding both endpoints
vector = np.linspace(0, 1, 12)[1:-1]  # Generate 12 points, then remove the first and last
print(vector)
