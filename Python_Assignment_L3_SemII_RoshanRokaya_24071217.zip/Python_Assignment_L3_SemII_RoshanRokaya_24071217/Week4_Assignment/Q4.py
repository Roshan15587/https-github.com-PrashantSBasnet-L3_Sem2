import numpy as np

# Create a (3,4) matrix with ones on the diagonal
matrix = np.zeros((3, 4))
np.fill_diagonal(matrix, 1)

print(matrix)
