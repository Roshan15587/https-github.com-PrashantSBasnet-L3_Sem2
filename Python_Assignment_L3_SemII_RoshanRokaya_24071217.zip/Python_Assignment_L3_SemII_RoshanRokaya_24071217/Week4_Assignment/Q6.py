# Input at least 10 numbers from the user
numbers = input("Enter at least 10 numbers separated by spaces: ").split()

# Convert input strings to integers
numbers = list(map(int, numbers))

# Check if the list has at least 10 elements
if len(numbers) < 10:
    print("Please enter at least 10 numbers.")
else:
    #  Sort the list
    numbers.sort()
    print("Sorted list:", numbers)

    # Perform slicing
    print("Elements from index 2 to 5:", numbers[2:6])   # includes index 2, excludes 6
    print("Elements from index 5 to 8:", numbers[5:9])
    print("Elements from index 2 to 9:", numbers[2:10])
