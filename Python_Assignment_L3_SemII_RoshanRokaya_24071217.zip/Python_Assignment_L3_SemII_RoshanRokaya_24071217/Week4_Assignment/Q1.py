import numpy as np

# Create a null (zero) vector of size 10
vector = np.zeros(10)

# Set the fifth element (index 4) to 1
vector[4] = 1

print("Resulting vector:", vector)
