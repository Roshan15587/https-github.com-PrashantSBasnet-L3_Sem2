import numpy as np
def main():
    
    size = 10  
    random_array = np.random.randint(0, 100, size=size) 
    
    print("Original random array:")
    print(random_array)
    print(f"Shape: {random_array.shape}")
    
    
    sorted_array = np.sort(random_array)
    print("Sorted array:")
    print(sorted_array)
    
    
    reshaped_2x5 = sorted_array.reshape(2, 5)
    print("Reshaped to 2x5 matrix:")
    print(reshaped_2x5)
    print(f"Shape: {reshaped_2x5.shape}")
    reshaped_5x2 = sorted_array.reshape(5, 2)
    print("Reshaped to 5x2 matrix:")
    print(reshaped_5x2)
    print(f"Shape: {reshaped_5x2.shape}")
    print("Feasible dimensions for reshaping:")
    for i in range(1, size + 1):
        if size % i == 0:  
            j = size // i  
            print(f"({i}, {j})")

if __name__ == "__main__":
    main()