import pandas as pd
from datetime import datetime

# Create the employee data
data = {
    'EmployeeID': [101, 102, 103, 104, 105],
    'Name': ['John Smith', 'Alice Brown', 'Bob White', 'Emma Green', 'Charlie Red'],
    'Department': ['IT', 'HR', 'IT', 'Finance', 'HR'],
    'Age': [30, 28, 35, 40, 25],
    'Salary': [70000, 60000, 80000, 90000, 55000],
    'JoinDate': ['2018-07-15', '2020-03-10', '2016-11-01', '2012-05-25', '2021-06-01'],
    'ExperienceYears': [5, 3, 7, 11, 2]
}

# Convert to DataFrame
df = pd.DataFrame(data)

# Convert JoinDate to datetime
df['JoinDate'] = pd.to_datetime(df['JoinDate'])

print(df[['Name', 'Salary']])

it_employees = df[df['Department'] == 'IT']
print(it_employees)

older_than_30 = df[df['Age'] > 30]
print("Employees older than 30:\n", older_than_30)

avg_salary_by_dept = df.groupby('Department')['Salary'].mean()
print("\nAverage Salary by Department:\n", avg_salary_by_dept)

employee_count = df['Department'].value_counts()
print(employee_count)

df['Bonus'] = df['Salary'] * 0.10
print(df[['Name', 'Salary', 'Bonus']])

df['Department'] = df['Department'].replace('HR', 'Human Resources')
print(df[['Name', 'Department']])

earliest_date = df['JoinDate'].min()
longest_tenure_employees = df[df['JoinDate'] == earliest_date]
print(longest_tenure_employees)

df['SalaryCategory'] = df['Salary'].apply(lambda x: 'High' if x > 75000 else 'Low')
print(df[['Name', 'Salary', 'SalaryCategory']])

# Check duplicates
duplicates = df.duplicated('EmployeeID')
print("Any duplicates?:", duplicates.any())

# Remove if any
df = df.drop_duplicates('EmployeeID')

median_age = df['Age'].median()
print("Median Age of Employees:", median_age)
