import pandas as pd

# Create two sample Series
series1 = pd.Series([10, 20, 30, 40, 50])
series2 = pd.Series([1, 2, 3, 4, 5])

# Perform operations
addition = series1 + series2
subtraction = series1 - series2
multiplication = series1 * series2
division = series1 / series2

# Print results
print("Series 1:")
print(series1)

print("Series 2:")
print(series2)

print("Addition:")
print(addition)

print("Subtraction:")
print(subtraction)

print("Multiplication:")
print(multiplication)

print("Division:")
print(division)
