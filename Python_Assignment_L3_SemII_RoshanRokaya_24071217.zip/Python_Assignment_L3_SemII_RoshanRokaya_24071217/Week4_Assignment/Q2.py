import numpy as np
# Ask the user to input two numbers
a = int(input("Enter the number of rows (a): "))
b = int(input("Enter the number of columns (b): "))

# Generate a random array of shape (a, b)
# Random numbers between 0 and 1
random_array = np.random.rand(a, b)

# Print the array
print("Generated Random Array:")
print(random_array)

# Calculate the average of the array
average = np.mean(random_array)

# Print the average
print("Average of all elements in the array:", average)

