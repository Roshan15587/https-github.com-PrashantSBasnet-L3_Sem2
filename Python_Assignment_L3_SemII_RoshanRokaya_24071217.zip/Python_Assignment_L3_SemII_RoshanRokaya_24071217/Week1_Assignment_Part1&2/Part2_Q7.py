''' user for input '''
user_input = input("Enter a string: ")

'''Count letters and digits using list comprehensions''' 
letter_count = sum(char.isalpha() for char in user_input)
digit_count = sum(char.isdigit() for char in user_input)

print(f"Letters: {letter_count}")
print(f"Digits: {digit_count}")
