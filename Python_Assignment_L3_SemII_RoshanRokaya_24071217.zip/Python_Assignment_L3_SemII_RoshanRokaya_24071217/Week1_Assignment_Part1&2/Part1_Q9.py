Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> """This program convertsthe float value 7.2 to an integer."""
'This program convertsthe float value 7.2 to an integer.'
>>> num = int(7.2)
>>> print(f"7.2 as an integer value is : {num}")
7.2 as an integer value is : 7
