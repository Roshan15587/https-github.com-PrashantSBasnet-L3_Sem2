Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> """This program calculates 2 raised to the power of 10."""
'This program calculates 2 raised to the power of 10.'
>>> x = 2
>>> result = x**10
>>> print(f"2 to the 10thpower is : {result}")
2 to the 10thpower is : 1024
