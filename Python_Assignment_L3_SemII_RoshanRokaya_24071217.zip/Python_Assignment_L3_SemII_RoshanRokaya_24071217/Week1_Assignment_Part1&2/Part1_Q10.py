Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> """This program displays the unicode encoding for each character in the user's name."""
"This program displays the unicode encoding for each character in the user's name."
>>> name = "Roshan"
>>> unicode_values = [ord(char) for char in name]
>>> print(f"The Unicode encoding for your name is : {unicode_values}")
The Unicode encoding for your name is : [82, 111, 115, 104, 97, 110]
