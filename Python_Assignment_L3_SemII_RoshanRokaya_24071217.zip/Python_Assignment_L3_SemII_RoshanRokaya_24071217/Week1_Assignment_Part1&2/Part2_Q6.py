"""Use list comprehension to find the numbers"""
numbers = [num for num in range(1500, 2001) if num % 7 == 0 and num % 5 == 0]
print(f"Numbers divisible by 7 and multiple of 5 between 1500 and 2000 is: {numbers}")
