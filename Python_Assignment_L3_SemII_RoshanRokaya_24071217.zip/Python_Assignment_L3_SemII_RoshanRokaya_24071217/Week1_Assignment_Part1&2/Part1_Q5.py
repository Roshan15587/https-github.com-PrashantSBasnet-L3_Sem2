Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> """This program repeats the user's forename 5 times."""
"This program repeats the user's forename 5 times."
>>> forename = "Roshan"
>>> result = forename*5
>>> print(f"Your forename multiplied by 5 : {result}")
Your forename multiplied by 5 : RoshanRoshanRoshanRoshanRoshan
