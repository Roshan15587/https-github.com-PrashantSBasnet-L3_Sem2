"""Take input from user"""
num = int(input("Enter the number: "))

"""Check if the number is even or odd"""
if num%2==0:
     print("the number is even")
else:
    print("the number is odd")