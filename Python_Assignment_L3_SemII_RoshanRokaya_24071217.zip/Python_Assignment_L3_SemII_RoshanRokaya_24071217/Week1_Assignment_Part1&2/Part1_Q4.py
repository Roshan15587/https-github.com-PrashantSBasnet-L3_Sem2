Python 3.13.1 (tags/v3.13.1:0671451, Dec  3 2024, 19:06:28) [MSC v.1942 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> """This program calculates the difference between 7 factorial and 5 factorial."""
'This program calculates the difference between 7 factorial and 5 factorial.'
>>> import math
>>> result = math.factorial(7) - math.factorial(5)
>>> print(F"7 factorial minus 5 factorial is : {result}")
7 factorial minus 5 factorial is : 4920
