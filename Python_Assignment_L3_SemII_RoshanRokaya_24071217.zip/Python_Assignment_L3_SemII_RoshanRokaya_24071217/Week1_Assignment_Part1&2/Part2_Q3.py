"""Prompt the user to enter a Celsius value"""
celsius = float(input("Enter the temperature in Celsius: "))

"""Convert Celsius to Fahrenheit"""
fahrenheit = (celsius * 9/5) + 32
print(f"{celsius} degrees Celsius is equal to {fahrenheit:.1f} degrees Fahrenheit")