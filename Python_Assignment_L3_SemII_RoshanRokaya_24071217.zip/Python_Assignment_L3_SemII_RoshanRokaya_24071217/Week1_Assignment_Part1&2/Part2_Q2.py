"""Prompt the user for two integer values"""
num1 = int(input("Enter the first integer: "))
num2 = int(input("Enter the second integer: "))

"""Perform the division and format the result to two decimal places"""
result = num1/num2
print(f"The result of the division is: {result:.2f}")

