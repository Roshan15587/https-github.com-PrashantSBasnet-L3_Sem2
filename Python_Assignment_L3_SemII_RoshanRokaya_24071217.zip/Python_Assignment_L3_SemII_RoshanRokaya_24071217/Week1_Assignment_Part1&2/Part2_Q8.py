import random  
def number_guessing_game():
    
    """Generate a random number between 1 and 100"""
    answer = random.randint(1, 100)  

    """Maximum attempts allowed"""
    attempts = 5  
    print("Welcome to the Number Guessing Game!")
    print("You have 5 attempts to guess the correct number between 1 and 100.")

    """Game loop for 5 attempts"""
    for i in range(attempts):
        guess = int(input("Enter your guess: "))   
        if guess < answer:
            print("Too low!") 
        elif guess > answer:
            print("Too high!")  
        else:
            print("Correct number! You've won!")  
            return  
    print("Game Over! The correct number was:", answer) 
number_guessing_game()